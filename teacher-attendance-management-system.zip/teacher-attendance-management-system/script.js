const STORAGE_KEY = "teacherAttendanceSystem_v1";
const defaultTeachers = [
  { id: "TCH-101", name: "Priya Sharma", subject: "Mathematics" },
  { id: "TCH-102", name: "Rahul Verma", subject: "Science" },
  { id: "TCH-103", name: "Ananya Rao", subject: "English" }
];
let state = loadState();

const dateInput = document.getElementById("attendanceDate");
const teacherForm = document.getElementById("teacherForm");
const tableBody = document.getElementById("teacherTableBody");
const searchInput = document.getElementById("searchInput");
const filterStatus = document.getElementById("filterStatus");

function localDateString(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (saved && Array.isArray(saved.teachers) && saved.attendance) return saved;
  } catch (error) {
    console.warn("Could not load saved attendance data.", error);
  }
  return { teachers: defaultTeachers, attendance: {} };
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function selectedDate() {
  return dateInput.value || localDateString();
}

function statusFor(teacherId) {
  return state.attendance[selectedDate()]?.[teacherId] || "Unmarked";
}

function setStatus(teacherId, status) {
  if (!state.attendance[selectedDate()]) state.attendance[selectedDate()] = {};
  if (status === "Unmarked") {
    delete state.attendance[selectedDate()][teacherId];
  } else {
    state.attendance[selectedDate()][teacherId] = status;
  }
  saveState();
  render();
}

function initials(name) {
  return name.trim().split(/\s+/).slice(0, 2).map(part => part[0] || "").join("").toUpperCase();
}

function render() {
  const query = searchInput.value.trim().toLowerCase();
  const filter = filterStatus.value;
  const teachers = state.teachers.filter(teacher => {
    const matchesQuery = [teacher.name, teacher.id, teacher.subject || ""].some(value => value.toLowerCase().includes(query));
    const status = statusFor(teacher.id);
    return matchesQuery && (filter === "all" || status === filter);
  });

  tableBody.innerHTML = "";
  teachers.forEach(teacher => {
    const status = statusFor(teacher.id);
    const row = document.createElement("tr");
    row.innerHTML = `
      <td><div class="teacher-cell"><span class="avatar">${escapeHtml(initials(teacher.name))}</span><span>${escapeHtml(teacher.name)}</span></div></td>
      <td>${escapeHtml(teacher.id)}</td>
      <td>${escapeHtml(teacher.subject || "—")}</td>
      <td><label class="sr-only" for="status-${safeId(teacher.id)}">Attendance status for ${escapeHtml(teacher.name)}</label>
        <select class="status-select" id="status-${safeId(teacher.id)}" data-teacher-id="${escapeHtml(teacher.id)}">
          ${["Unmarked", "Present", "Absent", "Leave"].map(option => `<option value="${option}" ${status === option ? "selected" : ""}>${option === "Leave" ? "On leave" : option}</option>`).join("")}
        </select>
      </td>
      <td><button type="button" class="delete-btn" data-delete-id="${escapeHtml(teacher.id)}" aria-label="Delete ${escapeHtml(teacher.name)}">Remove</button></td>`;
    tableBody.appendChild(row);
  });

  const noTeachers = state.teachers.length === 0;
  document.getElementById("emptyState").style.display = teachers.length ? "none" : "block";
  document.getElementById("emptyState").querySelector("h3").textContent = noTeachers ? "No teachers added yet" : "No matching teachers";
  document.getElementById("emptyState").querySelector("p").textContent = noTeachers ? "Use the form above to add your first teacher." : "Try changing your search or attendance filter.";
  document.getElementById("totalCount").textContent = state.teachers.length;
  document.getElementById("presentCount").textContent = state.teachers.filter(t => statusFor(t.id) === "Present").length;
  document.getElementById("absentCount").textContent = state.teachers.filter(t => statusFor(t.id) === "Absent").length;
  document.getElementById("leaveCount").textContent = state.teachers.filter(t => statusFor(t.id) === "Leave").length;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}
function safeId(value) {
  return String(value).replace(/[^a-zA-Z0-9_-]/g, "_");
}

teacherForm.addEventListener("submit", event => {
  event.preventDefault();
  const formData = new FormData(teacherForm);
  const name = String(formData.get("teacherName")).trim();
  const id = String(formData.get("teacherId")).trim();
  const subject = String(formData.get("subject")).trim();
  if (!name || !id) return;
  if (state.teachers.some(teacher => teacher.id.toLowerCase() === id.toLowerCase())) {
    alert("That Teacher ID already exists. Please use a unique ID.");
    return;
  }
  state.teachers.push({ id, name, subject });
  saveState();
  teacherForm.reset();
  render();
});

tableBody.addEventListener("change", event => {
  const select = event.target.closest("[data-teacher-id]");
  if (select) setStatus(select.dataset.teacherId, select.value);
});

tableBody.addEventListener("click", event => {
  const button = event.target.closest("[data-delete-id]");
  if (!button) return;
  const teacherId = button.dataset.deleteId;
  const teacher = state.teachers.find(item => item.id === teacherId);
  if (!teacher || !confirm(`Remove ${teacher.name} from the teacher directory?`)) return;
  state.teachers = state.teachers.filter(item => item.id !== teacherId);
  Object.values(state.attendance).forEach(day => delete day[teacherId]);
  saveState();
  render();
});

searchInput.addEventListener("input", render);
filterStatus.addEventListener("change", render);
dateInput.addEventListener("change", render);

document.getElementById("markAllBtn").addEventListener("click", () => {
  if (!state.teachers.length) {
    alert("Add teachers first.");
    return;
  }
  if (!confirm(`Mark all ${state.teachers.length} teachers as present on ${selectedDate()}?`)) return;
  if (!state.attendance[selectedDate()]) state.attendance[selectedDate()] = {};
  state.teachers.forEach(teacher => state.attendance[selectedDate()][teacher.id] = "Present");
  saveState();
  render();
});

document.getElementById("exportBtn").addEventListener("click", () => {
  const date = selectedDate();
  const rows = [["Date", "Teacher ID", "Teacher Name", "Subject", "Attendance"]];
  state.teachers.forEach(teacher => rows.push([date, teacher.id, teacher.name, teacher.subject || "", statusFor(teacher.id)]));
  const csv = rows.map(row => row.map(value => `"${String(value).replace(/"/g, '""')}"`).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `teacher-attendance-${date}.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
});

dateInput.value = localDateString();
render();
