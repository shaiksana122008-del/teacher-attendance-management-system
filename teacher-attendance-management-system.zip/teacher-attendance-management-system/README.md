# Teacher Attendance Management System

A beginner-friendly web project for managing daily teacher attendance.

## Features
- Add and remove teachers
- Record attendance by date: Present, Absent, On leave, or Unmarked
- Search teachers by name, ID, or subject
- Filter the directory by attendance status
- View daily attendance summary cards
- Mark all teachers present for a selected date
- Export the selected day's attendance to CSV
- Save data in the browser with `localStorage`
- Responsive layout for desktop and mobile

## Run locally
1. Download or extract the project ZIP.
2. Open `index.html` in a modern web browser.
3. Add teachers and record attendance.

No installation or server is required.

## Publish using GitHub Pages
1. Create a GitHub repository named `teacher-attendance-management-system`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository's root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish your site. The URL will usually be:
   `https://YOUR-USERNAME.github.io/teacher-attendance-management-system/`

Replace `YOUR-USERNAME` with your GitHub username.

## Important note
This is a front-end demonstration project. Attendance data is stored only in the current browser on the current device. It is not a secure shared database and does not sync between teachers or devices. Do not enter sensitive personal information.

## Technologies
- HTML
- CSS
- JavaScript
- Browser localStorage
